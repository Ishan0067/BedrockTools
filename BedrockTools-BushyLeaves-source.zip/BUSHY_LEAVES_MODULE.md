# Bushy Leaves native module

Target: BedrockTools / LeviLauncher ARM64 native framework.

## What it does
Hooks the six existing `BlockTessellator::TessellateFace*` signatures. When the
block name ends in `_leaves` (plus vanilla `leaves`, `azalea_leaves`, and
`flowering_azalea_leaves`), the original face is rendered plus additional copies
at small tangent-plane offsets. This creates a dense/fluffy leaf silhouette
without replacing the block texture or using a Bedrock resource pack.

## Settings
- `layers`: 1-9, default 5
- `spread`: 0.01-0.30, default 0.10
- `topBottom`: render extra top/bottom faces
- `sides`: render extra side faces
- `allLeaves`: master leaf filter

## Signatures used
- `BlockTessellatorTessellateFaceDown`
- `BlockTessellatorTessellateFaceUp`
- `BlockTessellatorTessellateFaceNorth`
- `BlockTessellatorTessellateFaceSouth`
- `BlockTessellatorTessellateFaceWest`
- `BlockTessellatorTessellateFaceEast`
- `RenderChunkCoordinatorSetAllDirty`

No hard-coded `libminecraftpe.so` address is used.
